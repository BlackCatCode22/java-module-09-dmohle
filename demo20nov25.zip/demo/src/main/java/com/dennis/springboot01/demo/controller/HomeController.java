package com.dennis.springboot01.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {

    @GetMapping("/")
    public String home() {

        return """
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <title>Spring Boot Home Page</title>
                    <style>
                        body {
                            background-color: teal;
                            font-family: Arial, Helvetica, sans-serif;
                            margin: 0;
                            padding: 0;
                            color: white;
                            display: flex;
                            justify-content: center;
                            align-items: center;
                            height: 100vh;
                        }
                        .container {
                            text-align: center;
                            background: rgba(0, 0, 0, 0.25);
                            padding: 40px;
                            border-radius: 12px;
                            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                            width: 70%;
                            max-width: 600px;
                        }
                        h1 {
                            margin-bottom: 10px;
                            font-size: 2.4rem;
                        }
                        p {
                            font-size: 1.2rem;
                        }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <h1>Welcome to Your Spring Boot App</h1>
                        <p>Hello Dennis! Your controller is working perfectly 🎉</p>
                        <p>This page is generated directly from your Java controller.</p>
                    </div>
                </body>
                </html>
                """;
    }
}
